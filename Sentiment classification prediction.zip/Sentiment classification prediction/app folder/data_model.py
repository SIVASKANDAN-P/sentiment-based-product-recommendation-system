from pydantic import BaseModel
from typing import Optional

class InputDataModel(BaseModel):
	user_name : str


class OutputDataModel(BaseModel):
	product1 : str
	product2 : str
	product3 : str
	product4 : str
	product5 : str
