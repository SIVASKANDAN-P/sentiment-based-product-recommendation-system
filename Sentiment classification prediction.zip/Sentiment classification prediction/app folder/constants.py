MODEL_NAME_LOGISTIC = r"C:\Users\sivaskandan\Desktop\fastapi\Sentiment classification prediction\Model files\logistic_regression_tuned_2024-03-17 11_42_35.380849.pkl"
MODEL_NAME_RANDOM_FOREST = r"C:\Users\sivaskandan\Desktop\fastapi\Sentiment classification prediction\Model files\random_forest_grid_tuned_2024-03-17 11_52_44.796718.pkl"
MODEL_NAME_XGBOOST = r"C:\Users\sivaskandan\Desktop\fastapi\Sentiment classification prediction\Model files\xg_boost_grid_tuned_2024-03-17 12_23_06.796356.pkl"
FINAL_FEATURES = ['reviews_username','name','reviews_rating']
RATING_ITEM = r"C:\Users\sivaskandan\Desktop\fastapi\Sentiment classification prediction\files\item_final_rating.csv"
RATING_USER = r"C:\Users\sivaskandan\Desktop\fastapi\Sentiment classification prediction\files\user_final_rating.csv"
ITEM_MAP=r"C:\Users\sivaskandan\Desktop\fastapi\Sentiment classification prediction\files\item.csv"
USER_MAP=r"C:\Users\sivaskandan\Desktop\fastapi\Sentiment classification prediction\files\user.csv"
NUM_ITEMS_PREDICT = 5
#FEATURES_TO_ENCODE = ['thal', 'slope', 'chest_pain_type', 'restecg']
#ONE_HOT_ENCODED_FEATURES = ['age', 'sex', 'resting_bp', 'cholestoral', 'fasting_blood_sugar',
#       'max_hr', 'exang', 'oldpeak', 'num_major_vessels', 'thal_0', 'thal_1',
#       'thal_2', 'thal_3', 'slope_0', 'slope_1', 'slope_2',
#       'chest_pain_type_0', 'chest_pain_type_1', 'chest_pain_type_2',
#       'chest_pain_type_3', 'restecg_0', 'restecg_1', 'restecg_2']
