import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
#import chardet
#import seaborn as sns
#from ydata_profiling import ProfileReport
import copy
from sklearn.metrics.pairwise import pairwise_distances
#from sklearn.model_selection import train_test_split
import re
import string
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
import spacy
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
import pickle
import chardet
#from sklearn.metrics import accuracy_score
#from sklearn.model_selection import cross_val_score
#from sklearn.model_selection import RandomizedSearchCV, GridSearchCV
#from sklearn.metrics import confusion_matrix, classification_report, roc_auc_score
#from sklearn.metrics import precision_score, recall_score, f1_score
#from textblob import TextBlob
#from wordcloud import WordCloud, STOPWORDS, ImageColorGenerator
#from imblearn.over_sampling import SMOTE
#from collections import Counter
#from sklearn.linear_model import LogisticRegression
#from sklearn.ensemble import RandomForestClassifier
#import xgboost as xgb
#from xgboost import XGBClassifier
from datetime import datetime

# Ignore warnings
import warnings
warnings.filterwarnings("ignore")
from constants import *

def fileopen(path):
  '''
  Detects the encoding of the file and Returns the file in given path.
  '''
  with open(path, "rb") as f:
    encoding = chardet.detect(f.read())["encoding"]
    file = pd.read_csv(filepath_or_buffer=path,encoding = encoding)
  return file


def uniq_dict(df,col):
  '''
  Creating a dict with uniques values in column and corresponding index starting
  from zero to length of unique values.
  '''
  uniq = list(df[col].unique()) # list of unique values in columns
  print("No of unique values : {}".format(len(uniq)))
  ind = range(0,len(df[col].unique())) # mapping value starting from 0 to list of columns
  result = dict(map(lambda x, y: (x,y), uniq, ind)) #creating dictionary mapping between unq and idx
  return result


def mapper(df,col):
  '''
  Mapping the unique value with numeric index starting from 0 to length of unique
  value
  '''
  print(col+" : ")
  dic = uniq_dict(df,col)
  df[col]=df[col].apply(lambda x: dic[x])
  return df


def pattern_check(text,pattern):
  '''
  This function check if there is a match for given pattern
  '''
  return re.search(pattern = pattern, string=text)


def text_preprocessing(sent):
  '''
  This function doese necessary preprocessing steps lower casing text, removing punctuations
  and removing stop words
  '''
  sent=sent.lower()
  sent=re.sub(r'[^\w\s]','',sent)
  word_tokens = word_tokenize(sent)
  clean_sent = [w for w in word_tokens if not w.lower() in stop_words]
  fin_sent=''
  first = True
  for w in clean_sent:
    if first:
      fin_sent = fin_sent + w
      first = False
    else:
      fin_sent = fin_sent + " " + w
  return fin_sent
