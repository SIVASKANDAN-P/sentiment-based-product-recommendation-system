import pickle
from fastapi import FastAPI
from constants import *
from utils import *
from data_model import *
import xgboost as xgb
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
import chardet
#import render_template
from fastapi.responses import HTMLResponse


app = FastAPI()
with open(MODEL_NAME_XGBOOST, 'rb') as f:
    loaded_model = pickle.load(f) # Load from constants

def apply_model(model, inference_data):
	# Prepare prediction dataframe
	user_final_rating = fileopen(RATING_ITEM)
	# Creating a dictionary with all unique names mapped to a number
	item_dict = fileopen(ITEM_MAP).to_dict()['Unnamed: 0']
	# Creating a dictionary with all unique usernames mapped to a number
	user_dict = fileopen(USER_MAP).to_dict()['Unnamed: 0']
	# Take the user ID as input.
	user = inference_data.user_name
	for key, value in user_dict.items():
	    if value == user:
	        user_input = key
	        break
	# user_input = user_dict[inference_data.user_name]
	# for key, value in user_dict.items():
	#     if value == user_input:
	#         user = key
	#         break
	#print("For user {}. {} \n The recomended items are : \n".format(user_input,user))
	d = user_final_rating.loc[user_input].sort_values(ascending=False)[0:20]
	recomended = []
	for i in range(NUM_ITEMS_PREDICT):
	    recomended.append(item_dict[int(d.index[i])])
	return recomended

@app.get('/')
def get_root():

	return {'message': 'Welcome to the Recomendation system API'}

@app.post("/predict", response_model=OutputDataModel)
async def post_predictions(inference_data: InputDataModel):

    recomended = apply_model(loaded_model, inference_data)

    response = {
        "product1": recomended[0],
        "product2": recomended[1],
		"product3": recomended[2],
        "product4": recomended[3],
		"product5": recomended[4]
    }
    return response
