from flask import Flask,render_template,request
import pickle
from fastapi import FastAPI
from constants import *
from utils import *
from data_model import *
import xgboost as xgb
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
import chardet
#import render_template
app = FastAPI()
with open(MODEL_NAME_XGBOOST, 'rb') as f:
    loaded_model = pickle.load(f) # Load from constants

def apply_model(name):
	# Prepare prediction dataframe
	user_final_rating = fileopen(RATING_ITEM)
	# Creating a dictionary with all unique names mapped to a number
	item_dict = fileopen(ITEM_MAP).to_dict()['Unnamed: 0']
	# Creating a dictionary with all unique usernames mapped to a number
	user_dict = fileopen(USER_MAP).to_dict()['Unnamed: 0']
	# Take the user ID as input.
	user = name
	for key, value in user_dict.items():
	    if value == user:
	        user_input = key
	        break
	# user_input = user_dict[inference_data.user_name]
	# for key, value in user_dict.items():
	#     if value == user_input:
	#         user = key
	#         break
	#print("For user {}. {} \n The recomended items are : \n".format(user_input,user))
	d = user_final_rating.loc[user_input].sort_values(ascending=False)[0:20]
	recomended = []
	for i in range(NUM_ITEMS_PREDICT):
	    recomended.append(item_dict[int(d.index[i])])
	return recomended


app = Flask(__name__)

@app.route("/", methods = ['POST','GET'])
def home():
    if request.method == 'GET':
        return render_template("main-page.html",placeholder_text = "HELLO")
    if request.method == 'POST':
        name = request.form['user_name']
        Recomendation=apply_model(name)
        return render_template("main-page.html",placeholder_text = Recomendation)

@app.route("/submit")
def submit():
    return "Hello from submit page"

if __name__ == '__main__':
    app.run()
